package com.mkyong.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mkyong.Repository.TopicRepoInterface;
import com.mkyong.bean.Topics;

@RestController
public class TopicController {
	
	
	
	@Autowired
	 private TopicRepoInterface service;

	@RequestMapping("/findAll")
	public List<Topics> findAll(){
		return  service.findAll();
		
	}
	
	
	 @RequestMapping("/findTopicById/{Topicid}")
	 public Topics findUserByTopicId( @RequestParam int Topicid) {
		 return service.findUserByTopicId(Topicid);
	 }
	 
	 
	 @RequestMapping(value="/update/{Topicid}", method=RequestMethod.POST)
	 public void updateById( @RequestBody Topics topic,@RequestParam int Topicid) {
		 service.updateById(topic, Topicid);
	 }
	 
}
