package com.mkyong.Repository;

import java.util.List;

import com.mkyong.bean.Topics;

public interface TopicRepoInterface {
	
	
	public List<Topics> findAll();	
    public Topics findUserByTopicId(int Topicid);
    public Topics create(Topics topic);
    public void updateById(Topics topic,int Topicid);
    
    
    

}
