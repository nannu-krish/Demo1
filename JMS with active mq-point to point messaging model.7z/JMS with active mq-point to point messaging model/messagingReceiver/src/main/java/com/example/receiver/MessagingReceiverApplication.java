package com.example.receiver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessagingReceiverApplication {

	public static void main(String[] args) {
		SpringApplication.run(MessagingReceiverApplication.class, args);
	}
}
