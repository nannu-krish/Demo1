package com.example.receiver;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class ReceiverController {
	
	@RequestMapping("/receive")
	public String Receivemessage() throws JMSException {
		
		ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
                "tcp://localhost:61616");
		  // Getting the queue

        Destination destination = new ActiveMQQueue("myQue");
        Connection connection = connectionFactory.createConnection();
        Session session = connection.createSession(false,
                Session.AUTO_ACKNOWLEDGE);
        //create a session
        // MessageConsumer is used for receiving (consuming) messages
            MessageConsumer consumer = session.createConsumer(destination);
            connection.start();
            //recieve the message
            // Here we receive the message.
            // By default this call is blocking, which means it will wait
            // for a message to arrive on the queue.
            Message msg =  consumer.receive();
            System.out.println(msg);
            String receiver = "I received" + ((TextMessage) msg).getText();
            //System.out.println("Received: " + ((TextMessage) msg).getText());
           // session.close();
            System.out.println(receiver);
        
		return receiver ;
		
	}
}

