package com.example.sender;


import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.messaging.Message;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SenderController {
	
	
	
	@RequestMapping("/send")
	public String SendMessage() throws JMSException {
		//to establish the configured connection and provide in built broker url
		//messaging broker converts a message from the sender protocol to receiver protocol
		 ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
	             "tcp://localhost:61616");
	     Destination destination = new ActiveMQQueue("myQue");
	     Connection connection = connectionFactory.createConnection();
	     // Create a session which is non transactional
	  // JMS messages are sent and received using a Session. We will
	     // create here a non-transactional session object. If you want
	     // to use transactions you should set the first parameter to 'true'
	     Session session = connection.createSession(false,
	             Session.AUTO_ACKNOWLEDGE);
	     String payload = "Hi I am sending message";
	     
	    
	            //create a message
	            TextMessage msg =  session.createTextMessage(payload);
	            //create a producer
	         // MessageProducer is used for sending messages (as opposed
	            // to MessageConsumer which is used for receiving them)
	            MessageProducer producer = session.createProducer(destination);
	            System.out.println("Send text '" + payload + "'");
	            //send the message 
	            producer.send(msg);
	           session.close();
	      
		
		return payload;
		
	}
	}
//}
//}
	     


