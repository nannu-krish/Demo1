package com.mkyong.Exception;

public class CourseApiException extends Exception {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4884788621846291659L;

	public CourseApiException(String message) {
		super(message);
	}
	
	
	

}
