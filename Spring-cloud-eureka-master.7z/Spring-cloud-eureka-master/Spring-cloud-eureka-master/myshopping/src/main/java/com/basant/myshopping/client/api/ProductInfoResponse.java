package com.basant.myshopping.client.api;

import java.util.List;

import com.basant.myshopping.client.api.ProductDetailsResponse.ProductDetailsResponseBuilder;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
@Getter
@Builder
@AllArgsConstructor

@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductInfoResponse {
    private String ConsumerName;
    private List<ProductDetailsResponse> productDetails;

   

}
