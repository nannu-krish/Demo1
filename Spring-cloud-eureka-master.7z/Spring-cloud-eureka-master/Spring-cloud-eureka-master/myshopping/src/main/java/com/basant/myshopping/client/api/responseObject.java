package com.basant.myshopping.client.api;

import java.util.List;

import com.basant.myshopping.client.api.ProductDetailsResponse.ProductDetailsResponseBuilder;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@AllArgsConstructor


@JsonIgnoreProperties(ignoreUnknown = true)
public class responseObject {

    private List<ProductInfoResponse> productInfo;

    private String message;

}
