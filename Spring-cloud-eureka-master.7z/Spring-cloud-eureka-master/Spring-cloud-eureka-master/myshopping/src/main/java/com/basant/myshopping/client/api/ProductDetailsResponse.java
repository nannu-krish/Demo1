package com.basant.myshopping.client.api;

import com.basant.myshopping.client.api.ProductDetailsRequest.ProductDetailsRequestBuilder;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@AllArgsConstructor

@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductDetailsResponse {
    private String productName;
    private Integer price;

    

}
