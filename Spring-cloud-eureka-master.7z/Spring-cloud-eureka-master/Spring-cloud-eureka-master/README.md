# Spring-cloud-eureka
How to use Eureak registry service and how can we register our application on Eureak server that we can access microservices using endpoint url
