package com.basant.order.service.api;

import java.util.List;

import com.basant.order.service.api.ProductInfoRequest.ProductInfoRequestBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
@Getter
@Builder
@AllArgsConstructor

@Setter
public class requestProduct {

    private List<ProductInfoRequest> productInfoRequest;

   

}
