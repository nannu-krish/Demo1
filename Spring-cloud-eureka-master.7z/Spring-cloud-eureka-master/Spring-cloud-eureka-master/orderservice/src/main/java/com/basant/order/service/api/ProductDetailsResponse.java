package com.basant.order.service.api;

import com.basant.order.service.api.ProductDetailsRequest.ProductDetailsRequestBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@AllArgsConstructor


public class ProductDetailsResponse {
    private String productName;
    private Integer price;

  

}
