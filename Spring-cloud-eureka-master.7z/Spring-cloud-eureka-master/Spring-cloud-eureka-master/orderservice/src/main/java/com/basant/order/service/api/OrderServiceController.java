package com.basant.order.service.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderServiceController {

	@GetMapping("/order-now/{price}")
	public String orderNow(@PathVariable long price) {
		return "Hi user, your order placed successfully with MRP$ :" + price;

	}

    @RequestMapping(value = "/store-now", method = RequestMethod.POST)
    public responseObject Store(@RequestBody requestProduct request) {
        responseObject res = responsemapper.map(request);
        return res;

    }

}
