package com.basant.order.service.api;

import java.util.List;

import com.basant.order.service.api.ProductDetailsResponse.ProductDetailsResponseBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
@Getter
@Builder
@AllArgsConstructor

@Setter
public class ProductInfoRequest {
    
    private String ConsumerName;
    List<ProductDetailsRequest> ProductDetailsRequest;

    

}
