package com.basant.order.service.api;

import java.util.ArrayList;
import java.util.List;

public class responsemapper {
    final static String MESSAGE = "Successfully Stored";

    public static responseObject map(requestProduct request) {
        // TODO Auto-generated method stub
        responseObject res1 = responseObject.builder()
            .productInfo(mapProductInfo(request.getProductInfoRequest()))
            // .setmessage("successfully stored")
            .message(MESSAGE)
            .build();
            
        

        return res1;
    }

    private static List<ProductInfoResponse> mapProductInfo(List<ProductInfoRequest> productInfoRequest) {

        // List<ProductInfoRequest> productInfoRequest1 =new ArrayList();
        List<ProductInfoResponse> prdresponse = new ArrayList<>();
        productInfoRequest.stream().forEach(productInfoRequest23 -> {
            ProductInfoResponse prdinforezsponse = ProductInfoResponse.builder().ConsumerName(productInfoRequest23.getConsumerName())
                .productDetails(mapproductDetails(productInfoRequest23.getProductDetailsRequest())).build();
            prdresponse.add(prdinforezsponse);
        });
        // prdresponse.add(e)
        return prdresponse;

    }

    private static List<ProductDetailsResponse> mapproductDetails(List<ProductDetailsRequest> productDetailsRequest) {
        // TODO Auto-generated method stub
        List<ProductDetailsResponse> pdrresponse = new ArrayList<>();
        productDetailsRequest.stream().forEach(qr -> {
        ProductDetailsResponse prdresponse = ProductDetailsResponse.builder()
                .productName(qr.getProductType())
                .price(qr.getPrice()).build();
            pdrresponse.add(prdresponse);
        });

        return pdrresponse;
    }

}
