package com.example.demo;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.restdocs.AutoConfigureRestDocs;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.restdocs.mockmvc.MockMvcRestDocumentation;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.jayway.restassured.module.mockmvc.RestAssuredMockMvc;



@RunWith(SpringRunner.class)
@SpringBootTest(classes= FraudServiceApplication.class)
@AutoConfigureRestDocs(outputDir = "target/snippets")
@AutoConfigureMockMvc 

public class BaseClass {
	
	@Autowired
	FraudController controller;
	
	@Autowired
	MockMvc mockMvc;
	
	@Before
	public void setup() {
		RestAssuredMockMvc.standaloneSetup(controller);
	}

	

	@Test
	public void should_accept_a_post_message() throws Exception {
	
		mockMvc.perform(MockMvcRequestBuilders.get("/fraud"))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcRestDocumentation.document("message"));
		
		
	} 
}
