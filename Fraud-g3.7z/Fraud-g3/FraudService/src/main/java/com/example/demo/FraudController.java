package com.example.demo;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FraudController {
	
	
	ResponseEntity<List<String>> fraud(){
		return ResponseEntity.status(101).body(Arrays.asList("marcin","josh"));
	}

}
