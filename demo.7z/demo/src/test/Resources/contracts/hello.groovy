org.springframework.cloud.contract.spec.Contract.make {
  request{
       method 'GET'
       url '/hello'
 headers{
     header('Content-Type','text/vnd.hello.v1+plain')
       }
   }
 response{
     status 200
     body(""" hello""")
 headers {
     header('Content-Type': 'text/vnd.hello.v1+plain')
  }
 }
 }
