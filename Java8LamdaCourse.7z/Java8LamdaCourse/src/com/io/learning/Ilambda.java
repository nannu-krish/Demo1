package com.io.learning;

@FunctionalInterface
public interface Ilambda {
	
	void foo();
	public static void mehod(){

	}

}
