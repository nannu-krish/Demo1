package com.io.learning;

public interface Condition {
	boolean condition(Person p);

}
