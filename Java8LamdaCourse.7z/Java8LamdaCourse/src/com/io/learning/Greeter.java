package com.io.learning;

public class Greeter {
	
	
	public void greet(greeting greeting){
		greeting.greet();
	}

	/*public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Greeter gt = new Greeter();
		gt.greet();
	}*/

	
	public static void main(String[] args) {
	// TODO Auto-generated method stub
	
	Greeter gt = new Greeter();
	
	greeting greeting = new greeting(){
			
			 public void  greet() {
				// TODO Auto-generated method stub
				System.out.println("helloWorld");
				
			};
	
	};
	greeting.greet();
	}
}

			 
			 
	//greeting greeting = new greeting();
	
	//gt.greet(greeting);
	
	 //Ilambda1  myLambdaExpression = () -> System.out.println("helloWorld");
	// Igreeting   myLambdaExpression = () -> {return "helloWorld";}
	 //using already Existing Interface
	 // Iadd addFunction =(int a, int b) ->   a+b;
	// myLambdaExpression.greet();
	
	
	
	

//}

/*interface Iadd{
	int  foo(int a,int b);
	
}

interface Ilambda1{
	void faa();
}*/