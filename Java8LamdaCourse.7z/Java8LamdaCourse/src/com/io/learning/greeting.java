package com.io.learning;

public class greeting implements Igreeting{

	

	@Override
	public void greet() {
		// TODO Auto-generated method stub
		System.out.println("helloWorld");
		
	}

}
