package com.io.learning.unit3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;



public class assignment {

	public static void main(String[] args) {
		
		ArrayList<String> list = new ArrayList<String>();
		
		 list.add("mCric");
	        list.add("Play");
	        list.add("Watch");
	        list.add("Glass");
	        list.add("Movie");
	        list.add("Girl");
	        list.add("mradha");
	        
	      //list.stream().forEachOrdered(l->l.startsWith("m")); 
	     // list.stream().
	      
	    /*  int index =  list.indexOf("mradha");
	      System.out.println(index);*/
	      //listPackages.indexOf(current_package);
	      
	      List<String> resultList = list.stream()
                  .filter(x -> x.startsWith("m"))
                  .collect(Collectors.toList());
	      
	     // List<String> resultList1 = list.stream().collect(Collectors.groupingBy(x -> x.startsWith("m")),Collectors.toList()) ;
	     
		
	}
}
		

		
		

