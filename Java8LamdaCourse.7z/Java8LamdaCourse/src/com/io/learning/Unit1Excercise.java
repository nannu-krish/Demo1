package com.io.learning;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Unit1Excercise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		List<Person> people = Arrays.asList(
				new Person("gayatri", "sundara",21),
				new Person("radhika", "mramachandran",22),
				new Person("nannapaneni", "krishna",25),
				new Person("gyanSagar", "spatanaik",29)
				);
				
				
		//sort list by last name
		
	Collections.sort(people, ( p3,p2)-> p3.getLastName().compareTo(p2.getLastName()));
		
		
		
		
		
		//create a method that prints all elements in the list
	
	//printAll(people);
	printConditionallyInterface(people, p->false);
	
		
		//create a method that prints last name begining with s
				
	
	//printConditionallyInterface(people, ( p1,p2)-> p1.getLastName().compareTo(p2.getLastName()));

	printConditionallyInterface(people,p ->  p.getLastName().startsWith("m"));
	
 // Optional p3 = (p) ->  p.getLastName().startsWith("m");
	 List<Person> filtered = people.stream().filter( p ->p.getLastName().startsWith("m")).collect(Collectors.toList());
	
	 Collections.sort(people, ( p3,p2)-> p3.getLastName().compareTo(p2.getLastName()));
	}
	
	

	/*private static void printAll(List<Person> people) {
		// TODO Auto-generated method stub
		for(Person p :people){
			System.out.println("prints all elements in the list in sorted order"+p);
		}
		
	}*/

	
	/*//using conditional interface
	private static void printConditionallyInterface(List<Person> people,
			Condition condition) {
		// TODO Auto-generated method stub
		for(Person p:people){
			if (condition.condition(p) ){
		System.out.println(p);
		}
		}
			
		

}*/
	//using predicate
	private static void printConditionallyInterface(List<Person> people,
			Predicate<Person> condition) {
		// TODO Auto-generated method stub
		for(Person p:people){
			if (condition.test(p) ){
		System.out.println(p);
		}
		}
			
		

}
}
