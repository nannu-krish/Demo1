package com.io.learning;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class Unit1UsingJava7 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		List<Person> people = Arrays.asList(
				new Person("gayatri", "sundara",21),
				new Person("radhika", "mramachandran",22),
				new Person("nannapaneni", "mkrishna",25),
				new Person("gyanSagar", "mspatanaik",29)
				);
				
				
		//sort list by last name
		
		Collections.sort(people, new  Comparator<Person>(){

			@Override
			public int compare(Person o1, Person o2) {
				// TODO Auto-generated method stub
				
				return o1.getLastName().compareTo(o2.getLastName());
			}
			
		});
		
		
		
		
		//create a method that prints all elements in the list
		
		
	printAll(people);
		
		//create a method that prints last name begining with s
	
	printLastNameBEginingWithS(people);
	printConditionally(people, "l");
	
	printConditionallyInterface(people, new Condition(){

		@Override
		public boolean condition(Person p) {
			// TODO Auto-generated method stub
			

boolean b= p.getLastName().startsWith("m");
System.out.println(b);
return b;
		}
		
	});
	
	

	
	
	
	
				

	}

	private static void printConditionallyInterface(List<Person> people,
			Condition condition) {
		// TODO Auto-generated method stub
		for(Person p:people){
			if (condition.condition(p) ){
		System.out.println(p);
		}
		}
			
		
	}

	private static void printLastNameBEginingWithS(List<Person> people) {
		// TODO Auto-generated method stub
		for(Person p :people){
			if (p.getLastName().startsWith("s")){
				System.out.println("prints last name begining with s"+p);
			
				
			}
			
		}
		
		
	}
	

	private static void printAll(List<Person> people) {
		// TODO Auto-generated method stub
		for(Person p :people){
			System.out.println("prints all elements in the list in sorted order"+p);
		}
		
	}

	
	private static void printConditionally(List<Person> people,String string){
		for(Person p :people){
			
			if(p.getLastName().startsWith(string)){
				System.out.println(p);
			}
			else{
				System.out.println("not found");
			}
		}
		
		
		
	}
	

}


  


