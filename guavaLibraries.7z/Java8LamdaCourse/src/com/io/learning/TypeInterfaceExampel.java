package com.io.learning;

public class TypeInterfaceExampel {
	
	public static void main(String[] args){
		myLambda1 myLambda = (String s)-> s.length();
		//myaLambda can be passes be as an argument
		//a kind of binding for 
		System.out.println(myLambda.foo("world"));
	}
	
	interface myLambda1{
		int foo(String s);
	}

}
