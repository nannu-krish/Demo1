package com.io.learning;



public interface Igreeting {
	public void greet();
//	int  foo(int a,int b);
	 // ()->system.out.print("hello world");
	 
	

}
