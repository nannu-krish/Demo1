package com.io.learning.Unit2;

import java.util.function.BiConsumer;

public class ExceptionHandlingExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] someNumbers= {1,2,3,4,5,6,7,89,34 };
		
		int key =2;
		//int key= 0;
		//processmethods(someNumbers,key);
		processMethodsusingLambdaFunctions(someNumbers,key, (i,k)->System.out.println(i+k));
		processMethodsusingLambdaFunctions(someNumbers,key, (i,k)->System.out.println(i/k));
	}

	private static void processMethodsusingLambdaFunctions(int[] someNumbers,
			int key, BiConsumer<Integer,Integer> consumer) {
		
		// TODO Auto-generated method stub
		for(int i:someNumbers){
			
			consumer.accept(i, key);
		
		
			
		}
		
	}

	/*private static void processmethods(int[] someNumbers, int key) {
		// TODO Auto-generated method stub
		
		for(int i: someNumbers){
			System.out.println(i+key);
		}
		
	}*/
	
	

}
