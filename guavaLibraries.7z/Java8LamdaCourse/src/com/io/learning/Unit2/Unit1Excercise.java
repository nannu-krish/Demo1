package com.io.learning.Unit2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.BaseStream;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Unit1Excercise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		List<Person> people = Arrays.asList(
				new Person("gayatri", "spatanaik",21),
				new Person("radhika", "ramachandran",22),
				new Person("nannapaneni", "krishna",25),
				new Person("gyanSagar", "spatanaik",29)
				);
		*/
		ArrayList<Person> list123 = new ArrayList<Person>();
	list123.add(new Person("gayatri", "spatanaik",20));
	list123.add(new Person("radhika", "ramachandran",20));
	list123.add(new Person("nannapaneni", "krishna",25));
	list123.add(new Person("gyanSagar", "spatanaik",29));
	list123.add(new Person("harshita", "spatanaik",21));
	list123.add(new Person("gayatri", "spatanaik",24));
	//list.add(new Person("gayatri", "Krishna",21));
	
	/*.stream()
    .collect(
        Collectors.groupingBy(
            Person::getGender,                      
            Collectors.mapping(
                Person::getName,
                Collectors.toList()))); */
	
	
	Map<String, List<String>> namesByGender =list123.stream()
	
	.collect(
        Collectors.groupingBy(
        		Person::getLastName,                      
            Collectors.mapping(
                Person::getFirstName,
                Collectors.toList())));
	
	/*ArrayList<String> namesByGender1 = (ArrayList<String>) list.stream()
			.collect(
					 Collectors.groupingBy(
							 Person::getLastName,Collectors.mapping(
						                Person::getAge,
						                Collectors.toList())));*/
	Map<Integer, List<String>> namesByGender1 = list123.stream()
			.collect(
			        Collectors.groupingBy(
			        		Person::getAge,                      
			            Collectors.mapping(
			                Person::getFirstName,
			                Collectors.toList())));
				
			
			
			
					
	
	/*List<Book> books = 
		    library.stream()
		           .filter(b -> b.properties.entrySet().containsAll(criteria.entrySet()))
		           .collect(Collectors.toList());*/
	
	System.out.println(namesByGender);
	 List value= namesByGender.get("spatanaik");
	 //System.out.println("spatanaik:   "+namesByGender.get("spatanaik") );
	// Predicate<> pred = p ->p.getFirstName()=="gyansagar";
	// value.stream().filter(pred).forEach(str->System.out.println(str));
	 
	 
	// Predicate<? super String> pred = p->p.getFirstName()=="gyansagar"; 
	// namesByGender.get("spatanaik").stream().filter(pred);
	 
		//Predicate<Person> pred = (p)->p.getAge()==20; 
	 //namesByGender.get("spatanaik").stream().filter(pred); 
	

	 System.out.println("values to be printed"+value);
	 
	   value.stream()               
             .filter(valu -> !"gayatri".equals(valu))    
             .forEach(str->System.out.println(str));
	// System.out.println(result);
	 
	// result.forEach(System.out::println);
	 
	
	 //List lines = java.util.Arrays.asList("value");
	// System.out.println(lines);
//	boolean list3 =list1.stream().equals("gayatri");
	/* List<String> result = lines.stream()                // convert list to stream
             .filter(line -> !"mkyong".equals(line))     // we dont like mkyong
             .collect(Collectors.toList());              // collect the output and convert streams to a List

     result.forEach(System.out::println);
	 List<String> result = 
			 
			 
			 lists.stream()
			 .filter(list1 ->"gayatri".equals(list1)
					 .collect(Collectors.toList()))*/;
	
	 
	System.out.println(namesByGender1);
	List<String> result1234 = new ArrayList(namesByGender.keySet());
	System.out.println(result1234);
	ArrayList<Integer> result1 = new ArrayList(namesByGender1.keySet());
	System.out.println(result1);
	ArrayList<Integer> result123 = (ArrayList<Integer>) result1.stream().filter(i ->i>=25).collect(Collectors.toList());
	System.out.println(result123);
	
	//Collection<String> filtered = ((ArrayList<Person>) result1234).filter(i -> i =="krishna").collect(Collectors.toList());
	//ArrayList<String> result12345 = (ArrayList<String>) result.stream().filter(i ->i ="krishna").collect(Collectors.collectingAndThen(downstream, finisher));    
	//	print(filtered);
	
	
	
		//System.out.println(result123);
	
	//result.stream().forEach(action);
	//result.set(, element)
	//result.stream().findFirst();
	 // ArrayList<Person>  result23= result.stream().filter(p ->p.getFirstName()== "gayatri").collect(Collectors.toList());;
	 // System.out.println(result23);
	//ArrayList<result>  result23= (ArrayList<Person>) result.stream().filter(p ->p.getFirstName()== "gayatri").collect(Collectors.toList());
	
	// Collection<Stream<Person>> xList;
	    //xList = Arrays.asList(result.stream().filter(p ->p.getFirstName()=="gayatri").ma;
	//System.out.println(result);
	// System.out.println(result.stream().filter(p ->p.getFirstName()== "gayatri").collect(Collectors.toList()));
	// result.stream().filter(p ->p.getFirstName()== "gayatri").collect(Collectors.toList());
	//namesByGender.containsValue(()-->System.out.println();)
	
	/*List<Object> list1 = namesByGender.entrySet().stream().sorted(Comparator.comparing(e -> e.getKey()))
			.map(e -> new User(e.getKey(), e.getValue())).collect(Collectors.toList());
	*/
	
	//result.stream().filter(p ->p.getAge() >= 20).collect(Collectors.toList());			
				
		//sort list by last name
		
	//Collections.sort(people, ( p1,p2)-> p1.getLastName().compareTo(p2.getLastName()));
		
		
		
		
		
		//create a method that prints all elements in the list
	
	//printAll(people);
	//printConditionallyInterface(people, p->true);
//	performConditionallyInterface(people, p->true,p ->System.out.println(p));
	
	
		
		//create a method that prints last name begining with s
				
	
	//printConditionallyInterface(people, ( p1,p2)-> p1.getLastName().compareTo(p2.getLastName()));

	//printConditionallyInterface(people,p ->  p.getLastName().startsWith("m"));
	//performConditionallyInterface(people,p ->  p.getLastName().startsWith("m"),p ->System.out.println(p));
	//performConditionallyInterface(people,p ->  p.getLastName().startsWith("m"),p ->System.out.println(p.getLastName()));
	
	}
	
	

	/*private static void printAll(List<Person> people) {
		// TODO Auto-generated method stub
		for(Person p :people){
			System.out.println("prints all elements in the list in sorted order"+p);
		}
		
	}*/

	
	/*//using conditional interface
	private static void printConditionallyInterface(List<Person> people,
			Condition condition) {
		// TODO Auto-generated method stub
		for(Person p:people){
			if (condition.condition(p) ){
		System.out.println(p);
		}
		}
			
		

}*/
	//using predicate
/*	private static void printConditionallyInterface(List<Person> people,
			Predicate<Person> condition) {
		// TODO Auto-generated method stub
		for(Person p:people){
			if (condition.test(p) ){
		System.out.println(p);
		}
		}
			
		

}*/
	
	private static void performConditionallyInterface(List<Person> people,
			Predicate<Person> condition,Consumer<Person> consumer){
		
		for(Person p:people){
			if (condition.test(p) ){
		consumer.accept(p);
		}
		}
		
	}
	
	/* roster
     .stream()
     .collect(
         Collectors.groupingBy(
             Person::getGender,                      
             Collectors.mapping(
                 Person::getName,
                 Collectors.toList()))); */

	
	//List<Person> people1 

	
	
}
