package com.io.learning;

public class RunnableExample {

	public static void main(String[] args) {
		
		Thread thread = new Thread( new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println("printed inside Runnable");
				
			}
			
			
		});
		thread.run();
		
		// TODO Auto-generated method stub
		 Thread MyLamdaThread = new Thread(()->System.out.println("lamda Runnable"))
		 ;
		 MyLamdaThread.run();

	}

}
