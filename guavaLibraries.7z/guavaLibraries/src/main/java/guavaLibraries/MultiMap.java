package guavaLibraries;

import java.util.Collection;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.Multiset;

public class MultiMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Multimap<String,String> multimap = ArrayListMultimap.create();
		multimap.put("1", "one");
		multimap.put("2", "two");
		multimap.put("3", "three");
		multimap.put("4", "four1");
		multimap.put("4", "four2");
		multimap.put("4", "four3");
		
		
		
		System.out.println(multimap.asMap().size());
		System.out.println(multimap.asMap());
	boolean st=	multimap.containsEntry("2", "five");
	System.out.println(st);
		System.out.println(multimap.containsKey("3"));
		System.out.println(multimap.get("1"));
		//System.out.println(multimap.get("one"));
		System.out.println(multimap.entries());
		//multimap.replaceValues("4", multimap<value>,"five" );

		Collection<String> set = multimap.get("4");
		set.forEach(str ->System.out.println(str));
		
		
		
	}

}
