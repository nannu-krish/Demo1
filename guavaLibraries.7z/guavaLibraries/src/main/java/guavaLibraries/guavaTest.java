package guavaLibraries;

import java.util.Optional;

public class guavaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		guavaTest test = new guavaTest();
		Integer p1 = null;
		Integer p2= new Integer(10);
		//allows it to be empty 
		Optional<Integer> m1= Optional.ofNullable(p1)
				;
		Optional<Integer> m3 = Optional.of(p2);
	
		
		try{
			Optional<Integer> m2 = Optional.of(p1);
		}catch(Exception e){
			System.out.println("Exception:" +e);
			System.out.println(m1);
		}
		//throws null pointer exception if parameter is null
		//Optional<Integer> m2 = Optional.of(p1);
		
		//System.out.println(m1);	
		//System.out.println(m2);
		 Integer sum=test.sum(m1, m3);
		 System.out.println(sum);

	}
	
	
	public Integer sum(Optional<Integer> a,Optional<Integer> b){
		
		//Optional.isPresent - checks the value is present or not
		System.out.println("the value of a is present:"+a.isPresent());
		System.out.println("the value of b is present:"+b.isPresent());
		
		Integer value1 = a.orElse(new Integer(0));
		Integer value2 = b.get();
		Integer Sum;
		
		
		return  Sum  = value1+value2;
	}

}
