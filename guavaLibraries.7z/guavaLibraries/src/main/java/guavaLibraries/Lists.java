package guavaLibraries;

import java.util.Collection;
import java.util.List;
//import com.google.common.collect.Lists;






import com.google.common.base.Function;
import com.google.common.base.Predicates;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;

public class Lists {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> names = com.google.common.collect.Lists.newArrayList("John", "Adam", "Jane");
		
		
		List<String> reversed = com.google.common.collect.Lists.reverse(names);
		
		
		reversed.forEach(str->System.out.println(str));
		
		List<Character> chars = com.google.common.collect.Lists.charactersOf("John");
		
		System.out.println(chars.stream().count());
		
		chars.forEach(sys->System.out.println(sys));
		
		//com.google.common.collect.Lists.transform(names);
		Iterable<String> result= Iterables.filter(names, Predicates.containsPattern("a"));
		System.out.println(result);
		
		/*
		 Function<String, Integer> function = new Function<String, Integer>() {
		        @Override
		        public Integer apply(String input) {
		            return input.length();
		        }
		    };*/
		    
		   // Function<String, Integer> function1 = new Function<String, Integer>((str)->str.length());
		    List<Integer> result1 = com.google.common.collect.Lists.transform(names,(str)->str.length() );
		    System.out.println(result1);
		    List<String> names1 = com.google.common.collect.Lists.newArrayList("John", "Jane", "Adam", "Tom");
		    Collection<Integer> result11 = FluentIterable.from(names1)
		    .filter(x -> x.startsWith("J"))
		    .transform((str)->str.length())
		    .toList();
		    System.out.println(result11);
		    
		  System.out.println(com.google.common.collect.Lists.cartesianProduct(ImmutableList.of(
	    	       ImmutableList.of(1, 2),
	    	       ImmutableList.of("A", "B", "C"))));
		  
		  System.out.println(com.google.common.collect.Lists.partition(names1, 3))	;	  
		  
		  
		  
		   
		    
		    

	}
	

}
