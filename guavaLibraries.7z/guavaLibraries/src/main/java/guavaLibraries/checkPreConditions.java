package guavaLibraries;

import java.util.ArrayList;
import java.util.List;

import com.google.common.base.Preconditions;

public class checkPreConditions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		checkPreConditions condition = new checkPreConditions();
		try{
			condition.division(0, 2);
			
			condition.getArray(7);
			
		}catch(Exception e){
			System.out.println("Exception is"+e);
		}
		
		List<String> list = new ArrayList<String>();
		list.add("guava");
		list.add("citrus");
		condition.outputItems(list);
		
		List<String> list1 = new ArrayList<String>();
		try{
			condition.outputItems(list1);
		}catch(Exception e){
			System.out.println("exception is"+e);
		}
		
/*		List<String> list2 = new ArrayList<String>();
		list.add(" ");
		list.add(" ");
		
		try{
			condition.outputItems(list2);
		}catch(Exception e){
			System.out.println("exception is"+e);
		}*/
		
		
		
		System.out.println(condition.division(10, 2));
		System.out.println(condition.getArray(2));
		

	}

	
	public Integer  division(int a ,int b ){
		 Preconditions.checkNotNull(b,"the value of b is null"+b);
		 Preconditions.checkNotNull(a,"the value of a is null"+a);
		
		return a/b;
		
	}
	
	public Integer getArray(int Intger){
		
		int[] data =
			{1,2,3,4};
		Preconditions.checkElementIndex(Intger, data.length,"Array Out of bound");
		
		for(int i=0;i<Intger; i++){
			System.out.println(data[i]);
		}
		return 0;
		
	}
	
	
	public static void outputItems(List<String> items){
		Preconditions.checkArgument(items!=null, "the list cannot be null");
		Preconditions.checkArgument(!items.isEmpty(), "the list must not be empty");
		for(String item:items){
			System.out.println(item);
		}
	}
	

}



