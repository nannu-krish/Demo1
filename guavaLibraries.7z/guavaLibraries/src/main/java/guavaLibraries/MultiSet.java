package guavaLibraries;

import java.util.Set;

import com.google.common.collect.HashMultiset;
import com.google.common.collect.Multiset;
import com.google.common.collect.Multiset.Entry;

public class MultiSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Multiset<String> set =  HashMultiset.create();
		set.add("guava");
		set.add("citrus");
		set.add("mango");
		set.add("guava");
		set.add("guava");
		set.add("guava");
		set.add("mango");
		set.add("watermelon");
		
		
		//occurence of element
		System.out.println("occurence of mango:"+set.count("mango"));
		
		//size of multiset
		System.out.println("size:"+set.size());
		
		//get distinct elements of Set
		
		Set<String> distinctElements = set.elementSet();
		
		System.out.println("distinctelements");
		
		distinctElements.forEach(str->System.out.println(str));
		System.out.println("=======================");
		System.out.println("using multiSet");
	set.entrySet().forEach(str->System.out.println(str));
	System.out.println("=======================");
		set.add("avacodo", 3);
		set.remove("guava", 1);
		System.out.println("after modifications");
		set.entrySet().forEach(str ->System.out.println(str));
		System.out.println("=======================");
		set.remove("mango");
		System.out.println("after removing mango");
		set.entrySet().forEach(str-> System.out.println(str));
		System.out.println("=======================");
		
		
		
		
		
		
		
		

	}
	
	

}
