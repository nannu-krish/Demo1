package guavaLibraries;

import com.google.common.collect.HashBiMap;

public class BiMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		com.google.common.collect.BiMap<Integer,String> bimap = HashBiMap.create();
		bimap.put(10, "ten");
		bimap.put(20, "twenty");
		bimap.put(30, "thirty");
		//bimap.put(30, "thirty");
		
		System.out.println(bimap.get(10));
		System.out.println(bimap.replace(30, "thirty", "thirty1"));
		System.out.println(bimap.get(30));
		bimap.keySet().forEach(str->System.out.println(str));
		bimap.values().forEach(str->System.out.println(str));
		//System.out.println(bimap.get("twenty"));
		System.out.println(bimap.inverse().get("twenty"));
		
			
		
	}
	
	

}
