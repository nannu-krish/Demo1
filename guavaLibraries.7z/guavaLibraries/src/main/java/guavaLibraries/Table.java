package guavaLibraries;

import java.util.Map;
import java.util.Set;

import com.google.common.collect.HashBasedTable;


public class Table {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		com.google.common.collect.Table<String, String, String> employeeTable = HashBasedTable.create();
		employeeTable.put("ibm" , "name1", "101");
		employeeTable.put("ibm" , "name2", "102");
		employeeTable.put("ibm" , "name3", "103");
		
		employeeTable.put("cg" , "name4", "104");
		employeeTable.put("cg" , "name5", "105");
		employeeTable.put("cg" , "name6", "106");
		
		 employeeTable.put("TCS" ,"Ram","121");
	      employeeTable.put("TCS" ,"Shyam","122");
	      employeeTable.put("TCS", "Sunil","123");
	      
	    //get Map corresponding to IBM
	      Map<String,String> ibmEmployees =  employeeTable.row("ibm");
     // System.out.println(ibmEmployees);
      
      for(Map.Entry<String, String> entry : ibmEmployees.entrySet()) {
          System.out.println("Emp Id: " + entry.getKey() + ", Name: " + entry.getValue());
       }
		
      //get all the unique keys of the table
      Set<String> employers = employeeTable.rowKeySet();
      System.out.print("Employers: ");
      
      for(String employer: employers) {
         System.out.print(employer + " ");
      }
      
      System.out.println();

      //get a Map corresponding to 102
      Map<String,String> EmployerMap =  employeeTable.column("Ram");
      
      
      for(Map.Entry<String, String> entry : EmployerMap.entrySet()) {
         System.out.println("Employer: " + entry.getKey() + ", ID: " + entry.getValue());
      }	
		
      //Map<String,String> EmployerMap1 =  employeeTable

	}

}
